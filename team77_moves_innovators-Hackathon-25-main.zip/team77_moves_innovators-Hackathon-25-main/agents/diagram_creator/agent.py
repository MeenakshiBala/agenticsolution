from typing import Dict, Any
import random
from backend.utils.helpers import format_agent_response

class DiagramCreatorAgent:
    def __init__(self, client):
        self.client = client
    
    async def process(self, description: str) -> Dict[str, Any]:
        """Generate diagram from description"""
        # In a real implementation, this would call the Azure AI agent
        # For now, we'll simulate a response
        response = f"""I created a diagram based on: {description}

Diagram features:
- Flowchart style
- Color-coded components
- Annotations explaining key parts
"""
        
        # Simulate a diagram URL (in real implementation, this would be actual diagram data)
        diagram_url = f"https://dummyimage.com/600x400/0077cc/ffffff&text=Diagram+{random.randint(1,100)}"
        
        return {
            **format_agent_response(response),
            "diagramUrl": diagram_url
        }