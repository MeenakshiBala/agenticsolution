import asyncio
import os
from dotenv import load_dotenv
from azure.identity.aio import DefaultAzureCredential
from azure.ai.projects import AIProjectClient
from semantic_kernel.agents import AzureAIAgent
import logging

# Load configuration
load_dotenv()

class AzureAIAgentSystem:
    def __init__(self):
        self.credential = None
        self.project_client = None
        self.agents = {}
        
        # Agent IDs
        self.agent_ids = {
            "code_reader": os.getenv("CODE_READER_AGENT_ID"),
            "diagram_creator": os.getenv("DIAGRAM_CREATOR_AGENT_ID")
        }

    async def initialize(self):
        """Initialize with detailed logging"""
        logging.info("Starting initialization...")
        
        try:
            # 1. Initialize credentials
            self.credential = DefaultAzureCredential()
            logging.info("Azure credentials initialized")
            
            # 2. Create project client
            conn_str = os.getenv("AZURE_AI_PROJECT_CONNECTION_STRING")
            if not conn_str:
                raise ValueError("Missing connection string")
                
            self.project_client = AIProjectClient.from_connection_string(
                conn_str=conn_str,
                credential=self.credential
            )
            logging.info("Project client created")
            
            # 3. Initialize agents
            async with AzureAIAgent.create_client(credential=self.credential) as client:
                self.agents = {}
                for agent_name, agent_id in self.agent_ids.items():
                    try:
                        logging.info(f"Initializing {agent_name} (ID: {agent_id})")
                        agent_def = await client.agents.get_agent(agent_id=agent_id)
                        self.agents[agent_name] = AzureAIAgent(
                            client=client,
                            definition=agent_def
                        )
                        logging.info(f"{agent_name} initialized successfully")
                    except Exception as e:
                        logging.error(f"Failed to initialize {agent_name}: {str(e)}")
                        raise
                        
            logging.info("All agents initialized")
            
        except Exception as e:
            logging.error(f"Initialization failed: {str(e)}")
            raise

    async def process_query(self, query: str, agent_type: str):
        try:
            if agent_type not in self.agents:
                available_agents = ", ".join(self.agents.keys())
                raise ValueError(
                    f"Agent {agent_type} not found. Available agents: {available_agents}"
                )

            agent_def = self.agents[agent_type].definition

            # ✅ create a new client inside this function
            async with AzureAIAgent.create_client(credential=self.credential) as client:
                agent = AzureAIAgent(client=client, definition=agent_def)
                thread = await client.agents.create_thread()
                logging.info(f"Processing query for agent: {agent_type}")
                logging.info(f"Query content: {query}")
                try:
                    await agent.add_chat_message(thread_id=thread.id, message=query)
                    response = await agent.get_response(thread_id=thread.id)

                    if hasattr(response, 'content'):
                        return response.content
                    return str(response)

                finally:
                    await client.agents.delete_thread(thread.id)

        except Exception as e:
            logging.error(f"Error in {agent_type} processing: {str(e)}")
            raise


    async def close(self):
        """Clean up resources"""
        if self.credential:
            await self.credential.close()