import os
from dotenv import load_dotenv
from pydantic import BaseSettings

class Settings(BaseSettings):
    AZURE_AI_PROJECT_CONNECTION_STRING: str
    CODE_READER_AGENT_ID: str
    DIAGRAM_CREATOR_AGENT_ID: str
    
    class Config:
        env_file = ".env"

def load_config():
    load_dotenv()
    return Settings()