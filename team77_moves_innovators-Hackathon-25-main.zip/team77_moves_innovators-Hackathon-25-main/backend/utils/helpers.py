import json
from typing import Optional, Dict, Any

def format_agent_response(response: str) -> Dict[str, Any]:
    """Format agent response for consistent output"""
    try:
        # Try to parse as JSON if possible
        return json.loads(response)
    except json.JSONDecodeError:
        return {"text": response}

def validate_query(query: str) -> Optional[str]:
    """Validate user query"""
    if not query or not query.strip():
        return "Query cannot be empty"
    if len(query) > 2000:
        return "Query too long (max 2000 characters)"
    return None
