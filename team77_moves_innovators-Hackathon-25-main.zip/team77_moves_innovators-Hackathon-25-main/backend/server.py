from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import asyncio
from main import AzureAIAgentSystem
import uvicorn
import logging
logging.basicConfig(level=logging.DEBUG)
import traceback

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class QueryRequest(BaseModel):
    query: str
    agent: str  # "code_reader" or "diagram_creator"

agent_system = AzureAIAgentSystem()

@app.on_event("startup")
async def startup_event():
    await agent_system.initialize()

@app.on_event("shutdown")
async def shutdown_event():
    await agent_system.close()


@app.get("/")
async def root():
    return {
        "message": "Azure AI Agent System is running",
        "endpoints": {
            "process": "/api/process (POST)",
            "health": "/api/health (GET)"
        }
    }
@app.post("/api/test_agents")
async def test_agents():
    """Test endpoint to verify agents are working"""
    test_queries = {
        "code_reader": "Explain this Python code: print('hello')",
        "diagram_creator": "Create a flowchart for a login system"
    }
    
    results = {}
    for agent_name, query in test_queries.items():
        try:
            response = await agent_system.process_query(
                query=query,
                agent_type=agent_name
            )
            results[agent_name] = {
                "status": "success",
                "response": response[:200] + "..." if len(response) > 200 else response
            }
        except Exception as e:
            results[agent_name] = {
                "status": "error",
                "error": str(e)
            }
            
    return results

@app.post("/api/process")
async def process_query(request: QueryRequest):
    try:
        # Log the incoming agent type
        logging.debug(f"Incoming agent: {request.agent}")

        # Map frontend agent names to backend names
        agent_mapping = {
            "codeReader": "code_reader",
            "diagramCreator": "diagram_creator"
        }

        if request.agent not in agent_mapping:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid agent type. Allowed: {list(agent_mapping.keys())}"
            )

        # Process with the mapped agent name
        response = await agent_system.process_query(
            query=request.query,
            agent_type=agent_mapping[request.agent]
        )

        return {
            "status": "success",
            "response": response,
            "diagramUrl": None
        }

    except Exception as e:
        logging.error(f"Error processing query: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

    
@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "agents_initialized": True}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)