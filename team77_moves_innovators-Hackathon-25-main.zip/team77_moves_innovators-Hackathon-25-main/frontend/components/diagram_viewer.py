import streamlit as st
from PIL import Image
import io
import base64

def display_diagram(diagram_data: str):
    """Display diagram from URL or base64 data"""
    try:
        if diagram_data.startswith("http"):
            st.image(diagram_data, use_column_width=True)
        else:
            # Handle base64 encoded image
            image_data = base64.b64decode(diagram_data.split(",")[1])
            image = Image.open(io.BytesIO(image_data))
            st.image(image, use_column_width=True)
    except Exception as e:
        st.error(f"Failed to display diagram: {str(e)}")