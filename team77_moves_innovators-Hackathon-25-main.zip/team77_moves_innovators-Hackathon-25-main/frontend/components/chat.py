import streamlit as st

def chat_message(role: str, content: str):
    """Display a chat message with role styling"""
    with st.container():
        if role == "user":
            st.markdown(f"""
                <div style="
                    background-color: #e3f2fd;
                    padding: 10px;
                    border-radius: 10px;
                    margin: 5px 0;
                ">
                    <strong>You:</strong> {content}
                </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
                <div style="
                    background-color: #f5f5f5;
                    padding: 10px;
                    border-radius: 10px;
                    margin: 5px 0;
                ">
                    <strong>Agent:</strong> {content}
                </div>
            """, unsafe_allow_html=True)