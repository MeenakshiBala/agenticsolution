import streamlit as st
import requests
from PIL import Image
import io
import base64
import time
import json
import re

def format_json(data):
    """Pretty-print JSON content with indentation."""
    return f"```json\n{json.dumps(data, indent=2)}\n```"

# Configuration
BACKEND_URL = "http://localhost:8000/api/process"
DEFAULT_AGENT = "code_reader"

# Page setup
st.set_page_config(
    page_title="Azure AI Agent System",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
def load_css():
    """Load custom CSS if available, fail silently if not"""
    try:
        with open("frontend/assets/styles.css") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        pass  # Continue without custom styles

# Initialize session state
def init_session():
    if "conversation" not in st.session_state:
        st.session_state.conversation = []
    if "processing" not in st.session_state:
        st.session_state.processing = False

# Call backend API
def call_agent_api(query: str, agent: str):
    try:
        print(f"Sending to {agent} agent: {query[:50]}...")  # Debug
        response = requests.post(
            BACKEND_URL,
            json={"query": query, "agent": agent},
            timeout=60
        )
        print(f"Response status: {response.status_code}")  # Debug
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"API Error: {str(e)}")  # Debug
        st.error(f"API Error: {str(e)}")
        return None

# Main application
def main():
    init_session()
    load_css()
    
    st.title("Team77 MOVES Innovators")
    st.markdown("""
        This system processes your queries through a pipeline of specialized AI agents.
    """)
    
    # Sidebar
    with st.sidebar:
        st.header("Configuration")
        agent_mode = st.radio(
            "Agent Mode",
            ("Code Reader", "Diagram Creator", "Full Pipeline"),
            index=0
        )
        st.markdown("---")
        st.info("Select the agent(s) you want to use for processing.")
    
    # Main content
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("Input")
        query = st.text_area(
            "Enter your query:",
            height=150,
            placeholder="Describe what you want to analyze or visualize..."
        )
        
        if st.button("Submit", disabled=st.session_state.processing):
            if not query.strip():
                st.warning("Please enter a query")
            else:
                process_query(query, agent_mode)
    
    with col2:
        display_responses()
    
    # Conversation history
    if len(st.session_state.conversation) > 0:
        st.markdown("---")
        st.subheader("Conversation History")
        display_history()

def process_query(query: str, agent_mode: str):
    agent_map = {
        "Code Reader": "codeReader",
        "Diagram Creator": "diagramCreator",
        "Full Pipeline": "codeReader"
    }

    if agent_mode not in agent_map:
        st.error("Invalid agent selection")
        return

    st.session_state.processing = True

    st.session_state.conversation.append({
        "query": query,
        "responses": {},
        "timestamp": time.time()
    })

    try:
        # Step 1: Run Code Reader (for Code Reader & Full Pipeline modes)
        if agent_mode in ["Code Reader", "Full Pipeline"]:
            with st.spinner("Code Reader Agent processing..."):
                response = call_agent_api(query, agent_map["Code Reader"])
                print("✅ Code Reader response received:")
                print(response)
                if response:
                    st.session_state.conversation[-1]["responses"]["code_reader"] = response

        # Step 2: Full Pipeline - Pass Code Reader result to Diagram Creator
        if agent_mode == "Full Pipeline":
            code_response_obj = st.session_state.conversation[-1]["responses"].get("code_reader", {}).get("response")

            print("➡️ Full code response object:")
            print(code_response_obj)

            diagram_query = None
            # if isinstance(code_response_obj, dict) and "items" in code_response_obj:
            #     for item in code_response_obj["items"]:
            #         if item.get("content_type") == "text":
            #             diagram_query = item.get("text")
            #             break
        def clean_markdown(text):
            """Remove markdown for simple parsing by diagram agent"""
            text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # bold
            text = re.sub(r'`(.*?)`', r'\1', text)        # inline code
            text = re.sub(r'\[.*?\]\(.*?\)', '', text)    # links
            return text.strip()

        # Inside your loop:
        if isinstance(code_response_obj, dict) and "items" in code_response_obj:
            for item in code_response_obj["items"]:
                if item.get("content_type") == "text":
                    raw_text = item.get("text")
                    diagram_query = clean_markdown(raw_text)
                    break            

            print("➡️ Passing text to Diagram Creator:", diagram_query)

            if diagram_query:
                with st.spinner("Diagram Creator Agent processing..."):
                    response = call_agent_api(diagram_query, agent_map["Diagram Creator"])
                    print("✅ Diagram Creator response received:")
                    print(response)
                    if response:
                        st.session_state.conversation[-1]["responses"]["diagram_creator"] = response
            else:
                print("⚠️ No text found in Code Reader output to send to Diagram Creator.")

        # Step 3: Diagram Creator standalone
        elif agent_mode == "Diagram Creator":
            with st.spinner("Diagram Creator Agent processing..."):
                response = call_agent_api(query, agent_map["Diagram Creator"])
                print("✅ Diagram Creator response (standalone):")
                print(response)
                if response:
                    st.session_state.conversation[-1]["responses"]["diagram_creator"] = response

    finally:
        st.session_state.processing = False
        st.rerun()



# def process_query(query: str, agent_mode: str):
#     agent_map = {
#         "Code Reader": "codeReader",
#         "Diagram Creator": "diagramCreator",
#         "Full Pipeline": "codeReader"
#     }

#     if agent_mode not in agent_map:
#         st.error("Invalid agent selection")
#         return

#     agent_name = agent_map[agent_mode]  # This is the correct backend-facing name

#     st.session_state.processing = True
#     st.session_state.conversation.append({
#         "query": query,
#         "responses": {},
#         "timestamp": time.time()
#     })

#     try:
#         if agent_mode in ["Code Reader", "Full Pipeline"]:
#             with st.spinner("Code Reader Agent processing..."):
#                 response = call_agent_api(query, agent_name)  # ✅ Use the mapped name
#                 if response:
#                     st.session_state.conversation[-1]["responses"]["code_reader"] = response

#         if agent_mode == "Diagram Creator":
#             with st.spinner("Diagram Creator Agent processing..."):
#                 response = call_agent_api(query, "diagramCreator")
#                 if response:
#                     st.session_state.conversation[-1]["responses"]["diagram_creator"] = response

#         elif agent_mode == "Full Pipeline" and "code_reader" in st.session_state.conversation[-1]["responses"]:
#             code_response = st.session_state.conversation[-1]["responses"]["code_reader"]["response"]
#             with st.spinner("Diagram Creator Agent processing..."):
#                 response = call_agent_api(code_response, "diagramCreator")
#                 if response:
#                     st.session_state.conversation[-1]["responses"]["diagram_creator"] = response
#             # code_response = st.session_state.conversation[-1]["responses"]["code_reader"]["response"]
#             # with st.spinner("Diagram Creator Agent processing..."):
#             #     response = call_agent_api(code_response, "diagramCreator")  # ✅ This one is already okay
#             #     if response:
#             #         st.session_state.conversation[-1]["responses"]["diagram_creator"] = response
#     finally:
#         st.session_state.processing = False
#         st.rerun()


def display_responses():
    st.subheader("Responses")
    
    if not st.session_state.conversation:
        st.info("Submit a query to see agent responses")
        return
    
    latest = st.session_state.conversation[-1]
    
    if "code_reader" in latest["responses"]:
        with st.expander("Code Reader Response", expanded=True):
            response = latest["responses"]["code_reader"]["response"]
            
            # If it's a dict with 'items', extract the first text item
            if isinstance(response, dict) and "items" in response:
                text_items = [item.get("text") for item in response["items"] if item.get("content_type") == "text"]
                if text_items:
                    st.markdown(text_items[0])
                else:
                    st.markdown(format_json(response))
            else:
                st.markdown(format_json(response))
    if "diagram_creator" in latest["responses"]:
        with st.expander("Diagram Creator Response", expanded=True):
            response = latest["responses"]["diagram_creator"]["response"]

            if isinstance(response, dict) and "items" in response:
                text_items = [item.get("text") for item in response["items"] if item.get("content_type") == "text"]
                if text_items:
                    st.markdown(text_items[0])
                else:
                    st.markdown(format_json(response))
            else:
                st.markdown(format_json(response))


def display_history():
    for i, conv in enumerate(st.session_state.conversation[:-1]):
        with st.expander(f"Query {i+1}: {conv['query'][:50]}...", expanded=False):
            st.markdown(f"**Original Query:** {conv['query']}")
            
            if "code_reader" in conv["responses"]:
                st.markdown("**Code Reader:**")
                st.markdown(conv["responses"]["code_reader"]["response"])
            
            if "diagram_creator" in conv["responses"]:
                st.markdown("**Diagram Creator:**")
                st.markdown(conv["responses"]["diagram_creator"]["response"])

if __name__ == "__main__":
    main()